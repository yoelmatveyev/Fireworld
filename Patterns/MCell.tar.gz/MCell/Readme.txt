Mirek's Cellebration (MCell) v.4.20
Copyright (c) 1999, 2001 Mirek W�jtowicz, Lublin, Poland
All rights reserved.

Mirek's Cellebration (MCell) is a feature-rich 32-bit Windows
program whose main purpose is exploring existing and creating new
rules and patterns of Conway's Game of Life and other Cellular Automata.

MCell is free for non-commercial use.

You are free to put this program on a CD-ROM, but if you do so
please send me a notification (and a copy of the CD, if possible.)
And of course spread this program complete with all files.


Contacting the author
=====================

e-mail: info@mirekw.com, mirwoj@homemail.com
WWW: http://www.mirekw.com

WWW mirrors:
http://www.mirwoj.opus.chelm.pl/
http://psoup.math.wisc.edu/mcell/


What's new in MCell
===================

4.20.0.503, 19 Sep 2001
- User DLLs can be configurable and can handle the whole families of
  rules, not only single rules:
  - the existing CASetup() function was extended to be able to receive
    the rule definition,
  - a new optional DLL function CAConfig() can return an interactively
    specified rule definition,
  - rules setup dialog has a new [Configure DLL] button allowing
    invoking DLL's interactive interface.
  See "\MCell\UserDLLs\DLLs\Sources\D5_WeightedGen" project for an example
  of a configurable DLL.
- User DLLs' configurations are saved in pattern files!
- New rules family - Weighted Generations, designed and implemented by
  Brian Prentice as a configurable DLL.
- An  accurate timer has been implemented what allowed for a better
  handling of animations faster than 20 ms.
- New drawing functions:
  - Draw lines, shortcut <L> (press <Shift> to draw in orthogonal mode).
  - Draw rectangles, shortcut <R> (press <Shift> to draw squares)
  - Draw circles, shortcut <C>
  - Fill closed areas, shortcut <A>
- New "Draw" toolbar and "Draw" menu with all drawing functions.
- Rule field in the status bar shows the rule definition in the hint
  window.
- Removed obsolete commands:
  - Fill selection (replaced by 'Fill area')
  - Rectangle around selection (replaced by 'Draw rectangles')
- Changes in existing shortcuts:
  - "Cells shape" <H> => <Ctrl-H>
  - "Editing mode" <E> => 'Free-hand drawing' <D>
  - "Center pattern" - no shortcut
  - "Center around (0,0)" - no shortcut


4.0.0.483, 25.04.2001
- Support for new "General Binary" family of rules, with many rules
  from John Elliott.
- Support for new "Margolus" family of rules, with many rules from
  Tim Tyler.
- Birth on 0 neighbors is allowed in Life and Generations.
- Extended 1D binary family - the family features now the history.
  All existing 1DBi rules are interpreted as 2-state rules.
- New "Diversities" dialog, with options for the Noise, Black Hole,
  SuperNova, and Input stream.
- New "Period checker" option under the "Analysis" menu. Option allows
  automatic detection of oscillators' and ships' periods and ships' speed.
- "Favorite folders", automatically filled with folders containing most
  recently loaded patterns.
- File manager - folders' panel and files' panel can be resized vertically.
- Save as... dialog - extra text control allowing editing the pattern
  description and checkboxes allowing specifying what items should be
  saved with the pattern.
- Settings - possibility to specify that Save as... dialog should be
  always used for saving.
- Settings - possibility to specify if the current color palette name
  should be saved with the pattern.
- Settings - possibility to specify if Diversities settings should be
  saved with patterns.
- Settings/Rules - possibility to update one of user rules with the
  modified rule definition.
- Rules setup/configuration moved to a separate menu item "Rules".
- New button (#R) invoking the rules setup dialog.
- Random rules - possibility to specify if generated random rules are
  allowed to change the count of states.
- Random rules - possibility to specify max. count of states.
- New rules: Snake, Rake, Bustle, LavaLamp, Cubism, InverseLife, Glisserati,
  LowBrowFour, Mazectric, Circuit Genesis, BelZhab Sediment, MeteorGuns,
  Dragon, LivingOnTheEdge, FlamingStarbows, Empire, ModernArt, WireWorld,
  Colony, Knitting, Tanks, Wave, Honeycomb.
- New rules: Lines, SoftFreeze, Xtasy, ThrillGrill, Glissergy, Bloomerang,
  OrthoGo (Generations), RandomWalk, DLA (User DLLs), HistoricalLife (RTab),
  Snowflake, LogicRule (General binary), Hextenders, PipeFleas,
  Y_Chromosome (Wlife), Strata (Neumann binary)
- "Change state of all alive cells to..." option got a [Ctrl+F4] shortcut.
- Automation property Universe.Generation is read/write.
- General binary rules - possibility to import Life/Generations/Weighted Life
  rules.
- Rules setup dialog - new style of the page control.
- WLife rules setup - repaired "Symmetrical rule" function.
- Removed redundant "Running"/"Stopped" panel in the status bar.
- Single-click interface in the File Manager, switchable via file manager's
  local menu and the Settings dialog.
- Possibility to have underlined file names in single-click interface.
- View menu - options for showing/hiding all items of the user interface.
- Help menu - 2 new options: "View MCell's Web Page" and "Send me an e-mail".
- Many dialog windows got a "Help" button.
- Corrections in birth on 0 neighbors in Life, Generations and General binary
  rules.
- Removed bug with clearing S rules in Weighted Life.
- Removed bug with setting the grid color.
- Removed bug in opening patterns without changing current rules.
- Fixed errors in setup for 1D totalistic rules.
- Fixed bug making it impossible to rotate a pattern selection with a width
  of one cell.


3.00.0.425, 21.01.2000
- (OLE) Automation interface allowing writing external applications
  communicating with MCell.
- Most MCell options were exported as properties and methods of 9 exposed
  objects: theApplication, theUniverse, theWindow, theSelection, theUndo,
  theSeeding, theTransitions, theCorrelations, and thePalette.
- The active color palette is checked in menus.
- User DLLs creation in MSVC is greatly simplified - the DEF file is no
  longer necessary.
- New game - 1D binary CA.
- Over 30 1D binary rules, copied from the Martin Schaller�s library.
- Many new rules in Generations, Weighted Life, and in User DLLs.
- "Create a bitmap" option got a [Ctrl+Shift+B] shortcut.
- User DLLs - bug causing the keyword 'ALLCELLS' sometimes to be ignored
  removed.
- Settings/Rules/Rules table - [Del] key resets the active cell to 0.
- "Create a bitmap" dialog - possibility to make a bitmap out of a defined
  rectangular part of the universe.
  The dialog can be now closed also with [Esc] key.
- User DLLs - CASetup function gets the board size information in the 'Misc'
  parameter as a formatted string "SIZEX=x SIZEY=y".
- The 'Run' button no longer stays depressed when the pattern is running.


2.51.0.399 Beta, 20.12.1999
- Colors bar (F2) - a new button allowing color palette selection.
- Settings/Rules/Weighted Life - rules can be also edited in a text field.
- Traffic CA - when no wrapping, the rule automatically generates cells
  to the left and to the right of the board with probabilities p1 and p2.
- Colors menu - reorganization, count of colors/active state submenus
  changed to input boxes.


2.50.0.397 Beta, 12.12.1999
- Count of available states increased to 256!
- Redesigned Settings/Colors dialog and colors bar.
- Enhanced MCL files syntax that supports 256 states.
- Improved assigning of default extensions to saved patterns.
- The first attempt to loading bitmaps as patterns (File/Open special).
- Reduced memory consumption.
- Open button got a popup menu with the MRU files list.
- "File" menu - if there exist more than 5 MRU files, they are shown in
  a "Reopen" submenu.
- Statistics - the graph is displayed much faster.
- User DLLs optionally can contain a new exported procedure CAClose() that
  is invoked before the DLL module is closed.
- User DLLs optionally can contain a new exported procedure CAPass() that
  gets called both before and after each cycle.
- User DLLs - if the keyword 'ALLCELLS' appears in the second text
  parameter the evaluating function is called for all cells, without
  optimizations.
- User DLLs can be also programmed in Borland C++ Builder.
- Many new rules:
  Aurora, Busy Brain, Ebb&Flow II, Emergence, GreenHast, Hex Inverse Fire,
  Jitters, PuttPutt, Simple, Simple Inverse, Simple Inverse Fire,
  Starbursts, and more.


2.30.0.384 Beta, 21.11.1999
- 'About' box - e-mail and WWW labels are active and, when clicked,
  the default mailer or the browser initialized with the proper address
  is launched.
- "File" menu - options are reorganized, less often used options were
  put to submenus.
- File Manager, "File" menu - new option allowing getting only rules from
  selected pattern files.
- File Manager, "File" menu - new option allowing opening patterns without
  changing the active game and rule.
- Status bar shows for registered rules the rule name rather than its
  definition. The definition is shown only for rules not predefined in
  the program and in the user rules.
- Settings / rules - possibility to specify if the modified game/rule
  parameters in the board should be automatically popped to the settings
  dialog.
- New game - Larger than Life.
- Larger than Life game - many new rules copied from WinCA: Bugs,
  Bugsmovie, Gnarl, Majority, Majorly, Waffle.
- Settings/Colors - colors can be dragged and dropped between panels.
- Transitions, Correlations - precision was increased to 6 dac.


2.20.0.383, 31.10.1999
- User palettes got automatic hot keys in the menu.
- Coloring method - Standard/Alternate, is selectable also via the
  "Colors" menu.
- Much improved scrollbars handling and layout. Scrollbars thumbs' size
  represents the proportion of the visible area.
- RunN - the cycle at which the animation will stop is shown in the left
  panel of the status bar.
- New rules: Bombers, Ebb&Flow
- #COLORING - new keyword in .MCL files allowing specifying the coloring
  method, 1 (standard) or 2 (alternate).
  Example: #COLORING 2
- New "Neumann binary" game.
- New "Neumann binary" game rules (from Tomoaki Suzudo):
  Aggregation, Birds, Crystal2, Crystal3a, Crystal3b, Fredkin2, Fredkin3,
  Lake, Plankton, Pond, Typhoon.
- Seeding - possibility to select the statistical / exact randomizing.
- Seeding - possibility to show density in % or as decimal values.
- Windows resources usage radically reduced (by 50%).
- Status bar - small buttons opening game/rule/speed popup windows.


2.10.0.341 Beta, 29.09.1999
- RunN dialog - possibility to run up to the end of the page - most useful
  in 1D rules.
- General settings - possibility to configure if randomizing should reset
  the file name and the pattern description.
- Possibility to configure the minimal zoom level at which the grid can
  be displayed.
- New command-line parameter 'LOGGED' allows monitoring and logging the
  program startup.


2.10.0.340 Beta, 27.09.1999
- Correlations analysis.
- Correlations can be saved to and loaded from .CRL files
  (MCell\System\Correlations\folder).
- Program got faster by 40% (big thanks to Johan Bontes for his tips!)
- Weighted Life rules settings - Shift-clicking the "Randomize" button
  does not reset weights.
- Population log to an external .PLG file. File is loadable to Excel.
- New toolbar button for setting the grid on / off.
- Alternate coloring method for all rules without history (Life, Weighted Life,
  1-D, Traffic CA).
- Possibility to copy selection to the clipboard as semigraphics (.*oO)
- Shortcut: Ctrl+Shift+C
- Semigraphics can be pasted from the clipboard to the board.
- Statistics - a new checkbox allows enabling/disabling updating.
- New Weighted life rules: CrossPorpoises, Bricks, Fleas, Hogs, MazeMakers,
  Stampede, Simple hex crystal, Upstream, Vineyard, Vineyard2, Starbursts2,
  ZipperMakers


2.10.0.321 Beta, 09.09.1999
- "Undo all cycles" got a [Ctrl+Alt+Z] shortcut and a button.
- Error in RunN dialog initialization causing forcing "Run up to"
  option removed.
- "Repeat last seeding" got a [Ctrl+Shift+R] shortcut and an entry in
  the "File" menu.
- New "Colors" menu options: next / previous state, shortcuts '[' and ']'.
- New "Colors" menu option: Change state of all alive cells to...
- New "Colors" menu option: Change state X to state Y...
- New "Colors" menu option: Swap two states...
- Renamed Traffic CA parameters: Epsilon->Alpha, Gamma->Beta.
- Traffic CA new syntax: TRCA,A,B,D1,D2
- New "Animation" menu option - Run N cycles, that runs the animation
  using settings in the RunN dialog.
- New button "RunN cycles".
- RunN dialog contains now two action buttons:
  "Ok" - accepts changes and closes the dialog,
  "Run" - runs the pattern, the dialog stays open.
- All dialog windows save and restore their last screen positions.
- RunN dialog window is non-modal.
- Dialog windows open when program terminates open automatically upon
  next startup.
- RunN, Randomize dialogs - action buttons renamed to "Apply".
- Statistics dialog - possibility to show bar for state 0
- Statistics dialog - option for statistics of a defined area
- Statistics dialog - option for statistics of current row in 1D rules.
- Colors bar - Shift-click on any color panel sets the count of states.
- Alternate coloring schemes for Traffic CA. Selectable via Settings.
- Settings - new button allowing to reload settings from the program.
- Statistics - possibility to show distribution as % or as a decimal
  number.
- Transitions analysis
- 'Run' button stays depressed while the pattern is running.
- Transitions definitions are preserved between sessions.
- Transitions can be saved to and loaded from .TRN files
  (MCell\System\Transitions\folder).
- New "Analysis" menu with Statistics, Transitions, and, soon, with logs.


2.0.0.305,03.08.1999
- Improved detection of non-standard RLE files.
- Hot key for the Colors Bar (F2)
- Error with bad names of seed files removed.
- Possibility to configure randomizing rules tables sparseness
- Many new rules: FrostM, FrostN, Cars, Pond, Cheops, Cooties 2,
  Crawlers, EcoLiBra, Fire sticks, Ladders, Piranha, RanBrain.


2.0.0.302, 21.07.1999
- Error with saving color palettes removed.
- Many new patterns (in Career, Star Wars, etc.).
- User DLLs can be also programmed in C. Included are projects for MSVC.
- New "DNA" rule by Christopher G. Langton.
- User DLLs handle also 1-D rules.


2.0.0.296 Beta, 12.07.1999
- Subzooms 1/2 .. 1/64 (where single screen pixels correspond to more
  that 1 cell).
- Undo activity was not restored from previous sessions.
- Esc and Help are handled in RunN dialog.
- File Manager - new options in a local menu: Rename file and Delete file.
- File Manager - list of files is updated after "Save as...".
- Lines marking the universe border are thicker.
- "Generations" game rules can be defined using Rudy Rucker's NLUKY codes.
- "Rules" settings - additional spin button allows easy game selection.
- "Board" settings - Optimized redrawing in subzooms. Faster, but of
  lower quality.
- #PALETTE - new keyword in .MCL files allowing specifying color palettes.
  Example: #PALETTE 2_2_1
- When grid is not displayed, cells fill the whole fields, without
  1 pixel gap.
- Error with saving color palettes removed


2.0.0.281,04.07.1999
- New colors bar, easy active state selection.
- Reorganization of menus, new "Colors" menu.
- New module creating bitmaps: either of the window,
  or of the whole universe.
- Randomizing dialog: circular areas, interior/exterior,
  saving/restoring sets.
- Program properly restores the window size after terminating in
  maximized mode.
- Width of the File Manager is saved and restored.


2.0.0.260 Beta, 27.06.1999
- MCLife name changed to Mirek's Cellebration (MCell).
  The author of the new name is David Griffeath.
- New logo and program icon.
- Removed bug with <Tab> and <arrows keys> usage in dialog windows.


2.0.0.258 Beta, 25.06.1999
- Easy color palette selection from the 'Colors' menu.
- A new "Run n / Run to n cycles" dialog, possibility to specify how
  often should the board be redisplayed.
- New rules.


2.00.0.205 Beta, 02.06.1999
- New rule "Transers" (345/26/5) from John Elliott.
- Possibility of selecting the active drawing state/color.
- The "Colors' button" allows looping between available states/colors.
  Shift-click activates the previous state (color).
- The active color is displayed in the status bar, before
  the count of colors.
- Drawing with the Shift key pressed clears cells.
  Drawing with the Ctrl key pressed creates cells with state 1,
  regardless of the active color.
- Count of states increased to 25 (24 alive + 1 dead).
- "Faders" rule definition changed from 2/2/8 to more accurate 2/2/16
- New "Rules Table" Game, supporting Moore 8/9 and
  von Neumann 4/5 neighbourhoods.
- Weighted Life - buttons clearing all S or B rules from the list.
  Shift+Del button is no longer supported.
- Rules Table - button Clear;
- Randomizing the Rules Table.
- New David Griffeath's "Cyclic CA" Game.
- New Statistics dialog, the distribution graph. Shortcut: F9
- New pattern randomizing dialog, with many options.
- Shift-clicking the "Randomize" option performs randomizing
  using last settings, without opening the dialog.
- First "Cyclic CA" rules: CCA, 313
- Greenberg-Hastings Model in Cyclic CA.
- New "Colorize the pattern randomly" dialog. Shortcut: F4
- Possibility to save/load user color palettes
- Many new Cyclic CA rules:
  Perfect, Maps, GH Macaroni, Turbulent phase, Fossil debris,
  3-color bootstrap, Stripes, Cyclic spirals, GH, GH Weak spirals,
  GH Percolation mix, GH Multistrands.
- New "User DLL" Game - MCell got programmable from outside!
- Many new rules
- F5 refreshes also the list of files in the File Manager.
- The board does not have to be a square, x size can be
  different than y size.
- Increased board size, up to 100000 x 2500.
- Possibility to configure the max. count of cells in the
  universe that can go to Undo.
- The notation of the max. count of colors has changed -
  now it includes also 0, and is greater by 1 than in previous versions.
- New game type - "Specific rules", that contains hard-coded rules,
  otherwise impossible to specify.
- Traffic CA, 1-dimensional rule in Special rules game.
- Next big extensions in Random patterns generator.
- New concept of pattern seeds;
  available in the new  option "Seed / randomize" universe.
- Scroll bars added to the lattice area.
  The visibility of scroll bars can be set in the View menu.
- Settings - possibility to specify that only the top line should
  be saved in 1-D CA.
- Faster redrawing of large patterns

