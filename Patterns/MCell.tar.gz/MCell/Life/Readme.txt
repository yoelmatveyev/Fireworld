This folder contains selected patterns of different Life-like rules.
Most of the patterns come from famous patterns collections available
on the Internet. Patterns in Seeds folder come from Stephen Wright.
Full libraries can be downloaded from:

Alan Hensel:
http://www.mindspring.com/~alanh/lifep.zip

Paul Callahan:
ftp.cs.jhu.edu/pub/callahan/conways_life/

David I. Bell:
ftp://sunsite.unc.edu/pub/Linux/games/amusements/life/dblifelib-2.tgz
http://ww.canb.auug.org.au/~dbell/

Dieter Leithner and Peter Rott:
http://www.mindspring.com/~alanh/guns2.zip

Mark D. Niemiec
http://home.interserv.com/~mniemiec/

Stephen Silver
http://www.argentum.freeserve.co.uk/life.htm

Jason Summers
http://home.mieweb.com/jason/life/


Mirek Wojtowicz, June, July 1999
e-mail: mirwoj@homemail.com
