Life Minsky Register Machines
By Paul Chapman
paul@igblan.free-online.co.uk
25th March 2005

For more information visit www.igblan.free-online.co.uk/igblan/ca