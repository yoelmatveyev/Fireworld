// MSVC_Life.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule(int Generation,int col,int row,
                               int NW, int N,  int NE,
                               int W,  int Me, int E,
                               int SW, int S,  int SE)
{
  int iSum = 0;
  int newState;

  iSum = (NW >= 1) + (N >= 1) + (NE >= 1) + (W >= 1) +
         (E >= 1) + (SW >= 1) + (S >= 1) +  (SE >= 1);

  newState = 0;
  if (0 == Me) // dead
  {
    if (3 == iSum) newState = 1;
  }
  else // alive
  {
    if ((2 == iSum) || (3 == iSum)) newState = Me + 1;
  }
  return newState;
}
//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 2;       // 1 - 1D, 2 - 2D
  *CountOfColors = 5;  // count of states, 0..n-1
  //strcpy(ColorPalette, "MCell standard");  // optional color palette specification
  strcpy(Misc, "");   // optional extra parameters; none supported at the moment
}
