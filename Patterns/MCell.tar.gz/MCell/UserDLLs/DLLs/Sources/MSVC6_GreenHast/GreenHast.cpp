// GreenHast.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule(int Generation,int col,int row,
                               int NW, int N,  int NE,
                               int W,  int Me, int E,
                               int SW, int S,  int SE)
{
  int r = 0, d = 0;
  int prevState;

  prevState = (Me >> 2) & 3; // get the previous state
  Me = Me & 3;         // throw the previous state away

  switch (Me)
  {
    case 0: // dead
           {
             int i4Sum = 0;
             i4Sum = ((N&3) == 1) + ((E&3) == 1) + ((S&3) == 1) + ((W&3) == 1);
             r = 0; d = (i4Sum > 0) ? 1 : 0;
           }
           break;
    case 1: // alive
            r = 2; d = 0; break;
    case 2: // dying
            r = 0; d = 0; break;
  }
  return (r + d - prevState + 3) % 3 + (Me << 2); // store Me for next calls
}
//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 2;       // 1 - 1D, 2 - 2D
  *CountOfColors = 15;  // count of states, 0..n-1
  strcpy(ColorPalette, "2_2_1");  // optional color palette specification
  strcpy(Misc, "");   // optional extra parameters; none supported at the moment
}
