// Hodge.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

#define NUM_STATES 32

//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule(int Generation,int col,int row,
                               int NW, int N,  int NE,
                               int W,  int Me, int E,
                               int SW, int S,  int SE)
{
	int sum8 = NW + N + NE + W + E + SW + S + SE;
  int newState = 0;

  // CelLab's version
  if (Me == 0)
  {
    if (sum8 < 5)
    {
      newState = 0;
    }
    else
    {
      if (sum8 < 100)
      {
        newState = 2;
      }
      else
      {
        newState = 3;
      }
    }
  }
  else if ((Me > 0) && (Me < 31))
  {
    newState = ((sum8 >> 3) + 5) & 255;
  }

  if (newState > 31)
  {
    newState = 31;
  }
  if (Me == 31)
  {
    newState = 0;
  }

/*
  if (Me == 0)
  {
    if (sum8 > 23) newState = 3;
    else if (sum8 > 2) newState = 2;
  }
  else if (Me >= NUM_STATES - 1)
  {
    newState = 0;
  }
  else
  {
		newState = ((sum8 / 8) + 2) % NUM_STATES;
  }
*/

  return newState;
}

//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void  __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 2;       // 1 - 1D, 2 - 2D
  *CountOfColors = NUM_STATES;  // count of states, 0..NUM_STATES-1
  strcpy(ColorPalette, "Wood");  // color palette specification
  strcpy(Misc, "ALLCELLS");   // no optimizing
}
