// Template1D.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



//
// Calculate the new state of the 'Me' cell.
int __declspec(dllexport) __stdcall CARule1D(int Generation,int col,
                       int l10, int l9, int l8, int l7, int l6,
                       int l5,  int l4, int l3, int l2, int l1,
                       int Me,
                       int r1,  int r2, int r3, int r4, int r5,
                       int r6,  int r7, int r8, int r9, int r10)
{
  return (l2 + l1 + Me + r1 + r2) % 5;
}
//
// Setup the rule.
// The function is called immediatelly after this rule is selected in MCell.
void __declspec(dllexport) __stdcall CASetup(int* RuleType, int* CountOfColors, char* ColorPalette, char* Misc)
{
  *RuleType = 1;       // 1 - 1D, 2 - 2D
  *CountOfColors = 5;  // count of states, 0..n-1
  //strcpy(ColorPalette, "MCell standard");  // optional color palette specification
  strcpy(Misc, "");   // optional extra parameters; none supported at the moment
}
